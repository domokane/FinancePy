# Copyright (C) 2018, 2019, 2020 Dominic O'Kane

# TODO Fix this

import numpy as np

# from numba import njit, float64

from ..utils.global_types import OptionTypes
from ..utils.error import FinError

from .black_scholes_analytic import bs_value

# Analytical Black Scholes model implementation and approximations


# @njit(float64[:](float64, float64, float64, float64, float64[:],
#                 float64[:]), cache=True, fastmath=True)

########################################################################################


import numpy as np
from typing import Sequence

def option_implied_dbn(
    s: float,
    t: float,
    r: float,
    q: float,
    strikes: Sequence[float],
    sigmas: Sequence[float]
) -> np.ndarray:
    """This function calculates the option smile/skew-implied probability
    density function times the interval width."""

    if len(strikes) != len(sigmas):
        raise FinError("Strike and Sigma vector do not have same length.")

    num_steps = len(strikes)

    sigma = sigmas[0]
    strike = strikes[0]

    sigma = sigmas[1]
    strike = strikes[1]

    inflator = np.exp((r - 0) * t)
    dk = strikes[1] - strikes[0]
    values = np.zeros(num_steps)

    for ik in range(0, num_steps):
        strike = strikes[ik]
        sigma = sigmas[ik]
        v = bs_value(s, t, strike, r, q, sigma, OptionTypes.EUROPEAN_CALL.value)

        values[ik] = v

    # Calculate the density rho(K) dk
    densitydk = np.zeros(num_steps)

    for ik in range(1, num_steps - 1):
        d2_vdk2 = (values[ik + 1] - 2.0 * values[ik] + values[ik - 1]) / dk

        #       print("%d %12.8f %12.8f %12.8f" %
        #             (ik, strikes[ik], values[ik], d2_vdk2))

        densitydk[ik] = d2_vdk2 * inflator

    return densitydk
